package com.skycast;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkycastBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
