package com.skycast.service;

import com.skycast.model.User;
import com.skycast.repository.UserRepository;
import com.skycast.dto.UserSignupRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder; // to encode passwords

    // Register user
    public String registerUser(UserSignupRequest request) {
        // Check if email already exists
        if (userRepository.existsByEmail(request.getEmail())) {
            return "401::Email already exists";
        }

        // Convert DTO to Entity
        User user = new User();
        user.setUsername(request.getUsername());
        user.setLocation(request.getLocation());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));  // Encrypt password
        user.setRole(request.getRole());

        // Save user
        userRepository.save(user);

        return "200::User registered successfully";
    }

    // User login logic
    public String loginUser(String email, String rawPassword) {
        // Check if user exists
        User user = userRepository.findByEmail(email);
        if (user == null) {
            return "401::Invalid credentials";
        }

        // Validate password
        boolean isPasswordValid = passwordEncoder.matches(rawPassword, user.getPassword());
        return isPasswordValid ? "200::Login successful" : "401::Invalid credentials";
    }
}
