package com.skycast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkycastBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(SkycastBackendApplication.class, args);
    }
}
